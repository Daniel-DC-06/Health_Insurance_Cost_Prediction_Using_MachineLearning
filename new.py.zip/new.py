import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import math

# Load dataset
data = pd.read_csv("dataset /insurance.csv")  # ✅ Fixed file path

# Display basic info
print(data.head())
print(data.info())

# Convert categorical variables to numeric
data["smoker"] = data["smoker"].map({"yes": 1, "no": 0})  # ✅ Convert smoker to numeric

# ✅ Remove 'sex' and 'region' columns
data = data.drop(columns=["sex", "region"])

# Verify data types after encoding
print(data.dtypes)

# Prepare features and target variable
y = data["charges"]
X = data.drop("charges", axis=1)

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(X, y, train_size=0.80, random_state=1)

# Train Linear Regression model
lr = LinearRegression()
lr.fit(X_train, y_train)

# Model Performance
print("Test Score:", round(lr.score(X_test, y_test), 3))  # ✅ Fixed rounding
print("Train Score:", round(lr.score(X_train, y_train), 3))  # ✅ Fixed rounding

# Predictions and Error Calculation
y_pred = lr.predict(X_test)
rmse = math.sqrt(mean_squared_error(y_test, y_pred))
print("Root Mean Squared Error (RMSE):", rmse)

# ✅ Accept User Input for Prediction
print("\nEnter details for insurance cost prediction:")
age = int(input("Enter age: "))
bmi = float(input("Enter BMI: "))
children = int(input("Enter number of children: "))
smoker = input("Smoker (yes/no): ").strip().lower()
region = input("Enter the Region: ").strip().lower()
Gender = input("Enter the Gender: ").strip().lower()


# Convert inputs to model format
smoker = 1 if smoker == "yes" else 0

# Create input DataFrame
user_input = pd.DataFrame([[age, bmi, children, smoker]],
                          columns=X.columns)

# Make Prediction (Convert USD to INR)
predicted_cost = lr.predict(user_input)[0] * 83  # ✅ Convert USD to INR
print(f"\nPredicted Insurance Cost: ₹{predicted_cost:.2f}")
